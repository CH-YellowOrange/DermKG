**kg01_one_node**: One node of DermKG: 'basal cell carcinoma' and its direct neighbors. Numbers and edge widths give the smoothed P(concept | disease); the rules indicating the disease, its category and a sample of its training images are also shown.

**kg02_two_hops**: Two-hop knowledge neighborhood of 'basal cell carcinoma' (21 nodes, 41 edges). Inner ring: direct neighbors; outer ring: concept groups, rule premises, sibling diseases reached through shared rules and the super-category.

**kg03_one_case**: Reasoning chain for one test image (true diagnosis in bold: acne vulgaris). Annotated concepts activate clinical rules, which indicate candidate diseases that roll up along IS_A and SUBCLASS_OF.

**kg04_category_malignant_epidermal**: The 'malignant epidermal' category in DermKG: 5 diseases with their characteristic concepts (CHARACTERIZED_BY) and the 4 expert rules that point to them (premises via GOVERNED_BY, conclusions via INDICATES).

**kg05_super_malignant**: The 'malignant' branch of DermKG: 4 categories, 11 diseases, 18 concepts and 7 expert rules.

**kg06_knowledge_layer**: The DermKG knowledge layer (215 nodes, 741 edges; image nodes omitted). From the center outward: super-categories, categories, diseases in category sectors, clinical rules, concepts and concept groups. Rules and concepts are placed at the mean angle of the diseases they connect to.

**kg07_whole_graph**: The complete DermKG (3,452 nodes, 19,365 edges). Gray dots are the 3,230 images, placed as a band beside their diagnosed disease, so band density reflects the long-tailed class distribution. Knowledge edges and DIAGNOSED_AS are drawn; the 15,308 image-to-concept, image-to-rule and image-to-skin-type edges are omitted for readability.

**kg08_zoom_strip**: DermKG at increasing scale: (a) a single disease node and its neighbors, (b) the reasoning chain of one image, (c) the malignant branch, (d) the full knowledge layer.

