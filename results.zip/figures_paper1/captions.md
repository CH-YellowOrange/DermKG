**fig01_category_distribution**: Distribution of the nine disease categories across the stratified train, validation and test splits (log scale). Inflammatory conditions account for about 65% of images.

**fig02_disease_long_tail**: Long-tailed distribution of the 113 diseases (median 21 images per disease), colored by category.

**fig03_concepts_per_image**: Number of dermatologist-annotated concepts per image. Most lesions are described by only two to four of the 48 concepts (mean 3.11).

**fig04_concept_prevalence**: Prevalence of the 48 SkinCon concepts, grouped by the dermatological lexicon (primary lesion, secondary change, color, shape/surface, vascular pattern). Prevalence spans more than two orders of magnitude.

**fig05_vector_coverage**: Cumulative coverage of the 813 distinct concept vectors among 3230 images. A small number of generic patterns (e.g. Plaque + Erythema) describe a large fraction of lesions.

**fig06_vector_ambiguity**: Category composition of the 12 most frequent concept vectors. Identical concept descriptions map to several categories, which bounds the accuracy of any concept-only classifier.

**fig07_information_ceiling**: Upper bounds of concept-only diagnosis obtained by an in-sample oracle that predicts the best label for each distinct concept vector, compared with the majority-class and chance baselines at three levels of the hierarchy.

**fig08_kg_schema**: DermKG schema with 8 node types and 11 relation types (edge counts on arrows). Solid gray: structural relations read from annotations; dashed blue: knowledge and inference relations derived from training statistics and clinical rules.

**fig09_nodes_by_type**: Number of DermKG nodes per type (3,452 nodes in total).

**fig10_edges_by_relation**: Number of DermKG edges per relation type (19,365 edges in total).

**fig11_degree_distribution**: Rank-degree plot of DermKG nodes by type (log-log). Concept nodes act as high-degree hubs linking images, diseases and rules.

**fig12_disease_concept_matrix**: DermKG disease-to-concept profiles estimated on the training split. Columns are grouped by concept group and rows by disease category (white lines).

**fig13_category_concept_lift**: Concept enrichment per category (log2 lift of category-level prevalence over global prevalence, training split; concepts with at least 30 images). Red marks concepts characteristic of a category.

**fig14_concept_pmi**: Pointwise mutual information between concepts on the training split (pairs with fewer than 5 co-occurrences masked). Positive values underlie the CO_OCCURS relation.

**fig15_rule_validation**: Training-split validation of the 20 expert clinical rules. Dashed lines mark the strong-rule thresholds (lift 5, support 10) and the dotted line the moderate threshold (lift 2). All rules have lift above 1.

**fig16_rule_precision_recall**: Precision and recall of each expert rule with respect to its target diseases on the training split, sorted by lift. Letters give the assigned strength (S strong, M moderate).

**fig17_rule_coverage**: Share of images that activate at least one clinical rule, by category.

**fig18_main_macro_f1**: Category-level macro-F1 on the test set with 95% bootstrap confidence intervals (1,000 resamples). Gray: data-only baselines; blue: KG-based models.

**fig19_main_balanced_accuracy**: Category-level balanced accuracy on the test set with 95% bootstrap confidence intervals. The dotted line marks chance (1/9).

**fig20_results_vs_ceiling**: Test performance of the best baseline and the KG models relative to the concept-only ceiling (red) and the majority-class / chance reference (dotted).

**fig21_fusion_sensitivity**: Sensitivity of KG-Fusion to the mixture weight $\alpha$ and the rule weight $\lambda$ on the validation split. The dotted line marks the selected $\alpha$.

**fig22_per_category_recall**: Per-category test recall, categories sorted by training size (n = training images).

**fig23_confusion_baseline**: Row-normalized category confusion matrix of LogReg (bottomup) on the test set.

**fig24_confusion_kgfusion**: Row-normalized category confusion matrix of KG-Fusion on the test set.

**fig25_errors_to_inflammatory**: Fraction of each non-inflammatory category predicted as Inflammatory. Collapse toward the majority category is the dominant error mode.

**fig26_super_confusion**: Super-category confusion of KG-Fusion on the test set, obtained by aggregating category predictions along SUBCLASS_OF.

**fig27_topk_disease**: Top-k accuracy of fine-grained diagnosis over 113 diseases (differential diagnosis setting). The dashed line is the top-1 concept-only ceiling.

**fig28_skin_type**: Category-level balanced accuracy by Fitzpatrick skin type (test set; n = test images).

**fig29_rule_backed**: Test performance of KG-Fusion for predictions supported by at least one activated expert rule versus unsupported predictions.

**fig30_case_explanation**: Concept-level explanation for a test lesion (true: granuloma pyogenic). KG-Mixture attributes the predicted category (Benign dermal, via pyogenic granuloma) against the runner-up (Genodermatoses, via neurofibromatosis).

**fig31_calibration**: Reliability diagram of category predictions on the test set (bins with at least 5 images); ECE = expected calibration error.

